/*
 * Copyright (c) 2008-2015 Emmanuel Dupuy
 * This program is made available under the terms of the GPLv3 License.
 */

package jd.ide.eclipse.startup;

import org.eclipse.ui.IStartup;

/**
 * JDStartupClass
 * 
 * @project Java Decompiler Eclipse Plugin
 * @version 0.1.4
 */
public class JDStartupClass implements IStartup
{
	public void earlyStartup() {}
}
